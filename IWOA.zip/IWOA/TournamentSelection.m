function parents = TournamentSelection(expectation,nParents,tournamentSize)


if nargin < 4 || isempty(tournamentSize)
    tournamentSize = 4;
end

playerlist = ceil(size(expectation,1) * rand(nParents,tournamentSize));
% tournament
parents = tournament(playerlist,expectation);

function champions = tournament(playerlist,expectation)

playerSize = size(playerlist,1);
champions = zeros(1,playerSize);
for i = 1:playerSize
    players = playerlist(i,:);
    winner = players(1); 
    for j = 2:length(players) 
        score1 = expectation(winner,:);
        score2 = expectation(players(j),:);
        if score2(1) > score1(1) 
            winner = players(j);
        elseif score2(1) == score1(1)
            try 
                if score2(2) > score1(2)
                    winner = players(j);
                end
            catch
            end
        end
    end
    champions(i) = winner;
end