
clear all 
clc

SearchAgents_no=30; % Number of search agents

% Function_name='F1'; % Name of the test function that can be from F1 to F23 (Table 1,2,3 in the paper)

Function_name=[{'F1'} {'F2'} {'F3'} {'F4'} {'F5'} {'F6'} {'F7'} {'F8'} {'F9'} {'F10'} {'F11'} {'F12'} {'F13'} {'F14'} {'F15'} {'F16'} {'F17'} {'F18'} {'F19'} {'F20'} {'F21'} {'F22'} {'F23'} ]; % Name of the test function that can be from F1 to F23 (Table 1,2,3 in the paper)

Max_iteration=100; % Maximum numbef of iterations
runs=2;

for i = 1: size(Function_name,2)
    optimalValue = [];
    optimalValue1 = [];
for run=1:runs
% Load details of the selected benchmark function
[lb,ub,dim,fobj]=Get_Functions_details(Function_name{i});

[Best_score,Best_pos,WOA_cg_curve]=WOA(SearchAgents_no,Max_iteration,lb,ub,dim,fobj);
display(['The best solution obtained by WOA is : ', num2str(Best_pos)]);
display(['The best optimal value of the objective funciton found by WOA is : ', num2str(Best_score)]);
optimalValue = [optimalValue Best_score];
        
[IBest_score,IBest_pos,IWOA_cg_curve]=IWOA(SearchAgents_no,Max_iteration,lb,ub,dim,fobj);
display(['The best solution obtained by ISWOA is : ', num2str(IBest_pos)]);
display(['The best optimal value of the objective funciton found by ISWOA is : ', num2str(IBest_score)]);
optimalValue1 = [optimalValue1 IBest_score];
  
figure;
itr=[1:1:Max_iteration];
semilogy(itr,WOA_cg_curve,itr,IWOA_cg_curve)
title('Objective space')
xlabel('Iteration');
ylabel('Best score obtained so far');

axis tight
grid on
box on
legend('WOA','IWOA')
cd('Result/Figs')
savefig([Function_name{i},'_',num2str(run)]);
cd ..
cd ..
close all
end

CombinedbestScore = [optimalValue;optimalValue1];
cd('Result/Excel')
xlswrite(Function_name{i},CombinedbestScore);
cd ..
cd ..
    
WOAMean(i)=mean(optimalValue);
IWOAMean(i) = mean(optimalValue1);

WOAMin(i)=min(optimalValue);
IWOAMin(i) = min(optimalValue1);

WOAStd(i)=std(optimalValue);
IWOAStd(i) = std(optimalValue1);

end
% CombinedMean = [Pf_mean;Wf_mean;MWf_mean];
CombinedMean = [WOAMean;IWOAMean];
cd('Result/Mean')
xlswrite('CombinedMean',CombinedMean);
cd ..
cd ..

cd('Result/Min')
CombinedMin = [WOAMin;IWOAMin];
xlswrite('CombinedMin',CombinedMin);
cd ..
cd ..

CombinedSTD = [WOAStd;IWOAStd];
cd('Result/STD')
xlswrite('CombinedSTD',CombinedSTD);
cd ..
cd ..

