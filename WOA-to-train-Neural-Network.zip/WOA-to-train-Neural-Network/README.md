# WOA-to-train-Neural-Network
Whale Optimization Algorithm used to train Neural Network
